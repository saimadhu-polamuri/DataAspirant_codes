# AIOps Central – Unified Monitoring for GenAI Use Cases

A comprehensive post-production monitoring platform designed to provide centralized visibility, security oversight, and performance intelligence across all deployed GenAI applications.

## 🌟 Features

- **Business KPIs**: Cost tracking, revenue analysis, and user distribution metrics
- **Operational KPIs**: Uptime monitoring, performance metrics, and error tracking
- **Feedback KPIs**: Sentiment analysis, accuracy metrics, and user ratings
- **Observability KPIs**: Resource utilization, real-time logs, and model drift monitoring
- **Security KPIs**: Access control, encryption status, and threat intelligence

## 🛠 Tech Stack

- **Frontend**: React + TailwindCSS + Recharts
- **Backend**: Node.js + Express
- **Database**: MongoDB
- **Authentication**: JWT + RBAC
- **Monitoring**: OpenTelemetry

## 🚀 Getting Started

### Prerequisites

- Node.js (v18 or higher)
- MongoDB
- npm or yarn

### Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/aiops-central.git
cd aiops-central
```

2. Install dependencies:
```bash
# Install backend dependencies
cd backend
npm install

# Install frontend dependencies
cd ../frontend
npm install
```

3. Set up environment variables:
```bash
# Backend
cp .env.example .env
# Frontend
cp .env.example .env
```

4. Start the development servers:
```bash
# Start backend
cd backend
npm run dev

# Start frontend
cd ../frontend
npm run dev
```

## 📊 Dashboard Features

- Real-time monitoring and analytics
- Interactive visualizations
- Role-based access control
- Automated anomaly detection
- Security monitoring and alerts

## 🔒 Security

- JWT-based authentication
- Role-based access control
- Encrypted data transmission
- Audit logging
- Compliance monitoring

## 📝 License

MIT License - see LICENSE file for details 