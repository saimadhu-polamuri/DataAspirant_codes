import { useState } from 'react';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  AreaChart,
  Area,
  RadialBarChart,
  RadialBar,
} from 'recharts';
import { BuildingOfficeIcon, ChartBarIcon, ShieldCheckIcon, CpuChipIcon, UserGroupIcon, ArrowRightIcon, CheckCircleIcon, HomeIcon, Cog6ToothIcon, PlusIcon } from '@heroicons/react/24/outline';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  const [selectedProject, setSelectedProject] = useState('all');
  const [showNewProjectModal, setShowNewProjectModal] = useState(false);
  const [dateRange, setDateRange] = useState('30d'); // 7d, 30d, 90d, 1y
  const [compareMode, setCompareMode] = useState(false);
  const [selectedProjects, setSelectedProjects] = useState([]);

  // Project data
  const projects = [
    {
      id: 'iam-recommendations',
      name: 'IAM Recommendations',
      description: 'AI-powered access certification and privilege management system for enhanced security and compliance',
      businessKPIs: [
        { 
          name: 'Access Certification Efficiency',
          value: '85%',
          trend: 'up',
          description: 'Percentage of access reviews completed within SLA',
          target: '90%',
          history: [
            { date: '2024-01', value: 75 },
            { date: '2024-02', value: 78 },
            { date: '2024-03', value: 80 },
            { date: '2024-04', value: 82 },
            { date: '2024-05', value: 85 }
          ]
        },
        { 
          name: 'Time Reduction',
          value: '65%',
          trend: 'up',
          description: 'Reduction in time taken for access reviews',
          target: '70%',
          history: [
            { date: '2024-01', value: 45 },
            { date: '2024-02', value: 50 },
            { date: '2024-03', value: 55 },
            { date: '2024-04', value: 60 },
            { date: '2024-05', value: 65 }
          ]
        },
        { 
          name: 'Excessive Privileges Removed',
          value: '1,234',
          trend: 'up',
          description: 'Number of unnecessary access privileges removed',
          target: '1,500',
          history: [
            { date: '2024-01', value: 800 },
            { date: '2024-02', value: 900 },
            { date: '2024-03', value: 1000 },
            { date: '2024-04', value: 1100 },
            { date: '2024-05', value: 1234 }
          ]
        },
        { 
          name: 'Security Compliance',
          value: '92%',
          trend: 'up',
          description: 'Compliance score for access management',
          target: '95%',
          history: [
            { date: '2024-01', value: 85 },
            { date: '2024-02', value: 87 },
            { date: '2024-03', value: 89 },
            { date: '2024-04', value: 90 },
            { date: '2024-05', value: 92 }
          ]
        },
        { 
          name: 'Screen Fatigue Reduction',
          value: '75%',
          trend: 'up',
          description: 'Reduction in reviewer screen time',
          target: '80%',
          history: [
            { date: '2024-01', value: 60 },
            { date: '2024-02', value: 65 },
            { date: '2024-03', value: 68 },
            { date: '2024-04', value: 72 },
            { date: '2024-05', value: 75 }
          ]
        }
      ],
      operationalKPIs: [
        { 
          name: 'Model Accuracy',
          value: '94%',
          trend: 'up',
          description: 'Accuracy of access recommendations',
          target: '95%',
          history: [
            { date: '2024-01', value: 90 },
            { date: '2024-02', value: 91 },
            { date: '2024-03', value: 92 },
            { date: '2024-04', value: 93 },
            { date: '2024-05', value: 94 }
          ]
        },
        { 
          name: 'Response Time',
          value: '120ms',
          trend: 'down',
          description: 'Average response time for recommendations',
          target: '100ms',
          history: [
            { date: '2024-01', value: 150 },
            { date: '2024-02', value: 140 },
            { date: '2024-03', value: 130 },
            { date: '2024-04', value: 125 },
            { date: '2024-05', value: 120 }
          ]
        },
        { 
          name: 'Resource Usage',
          value: '65%',
          trend: 'stable',
          description: 'System resource utilization',
          target: '70%',
          history: [
            { date: '2024-01', value: 65 },
            { date: '2024-02', value: 65 },
            { date: '2024-03', value: 65 },
            { date: '2024-04', value: 65 },
            { date: '2024-05', value: 65 }
          ]
        }
      ],
      securityKPIs: [
        { 
          name: 'Threat Detection',
          value: '98%',
          trend: 'up',
          description: 'Percentage of potential threats detected',
          target: '99%',
          history: [
            { date: '2024-01', value: 95 },
            { date: '2024-02', value: 96 },
            { date: '2024-03', value: 97 },
            { date: '2024-04', value: 97 },
            { date: '2024-05', value: 98 }
          ]
        },
        { 
          name: 'False Positives',
          value: '2%',
          trend: 'down',
          description: 'Rate of false positive alerts',
          target: '1%',
          history: [
            { date: '2024-01', value: 5 },
            { date: '2024-02', value: 4 },
            { date: '2024-03', value: 3 },
            { date: '2024-04', value: 2.5 },
            { date: '2024-05', value: 2 }
          ]
        },
        { 
          name: 'Compliance Score',
          value: '95%',
          trend: 'up',
          description: 'Overall compliance rating',
          target: '98%',
          history: [
            { date: '2024-01', value: 92 },
            { date: '2024-02', value: 93 },
            { date: '2024-03', value: 94 },
            { date: '2024-04', value: 94 },
            { date: '2024-05', value: 95 }
          ]
        }
      ]
    },
    {
      id: 'threat-actor-review',
      name: 'Threat Actor Resume Review',
      description: 'Advanced AI-powered resume screening and threat actor identification system',
      businessKPIs: [
        { 
          name: 'Screening Efficiency',
          value: '90%',
          trend: 'up',
          description: 'Percentage of resumes screened within SLA',
          target: '95%',
          history: [
            { date: '2024-01', value: 80 },
            { date: '2024-02', value: 83 },
            { date: '2024-03', value: 85 },
            { date: '2024-04', value: 88 },
            { date: '2024-05', value: 90 }
          ]
        },
        { 
          name: 'High Risk Identification',
          value: '85%',
          trend: 'up',
          description: 'Accuracy in identifying high-risk candidates',
          target: '90%',
          history: [
            { date: '2024-01', value: 75 },
            { date: '2024-02', value: 78 },
            { date: '2024-03', value: 80 },
            { date: '2024-04', value: 82 },
            { date: '2024-05', value: 85 }
          ]
        },
        { 
          name: 'Threat Actor Matching',
          value: '92%',
          trend: 'up',
          description: 'Accuracy in matching known threat actors',
          target: '95%',
          history: [
            { date: '2024-01', value: 85 },
            { date: '2024-02', value: 87 },
            { date: '2024-03', value: 89 },
            { date: '2024-04', value: 90 },
            { date: '2024-05', value: 92 }
          ]
        },
        { 
          name: 'Screen Fatigue Reduction',
          value: '80%',
          trend: 'up',
          description: 'Reduction in reviewer screen time',
          target: '85%',
          history: [
            { date: '2024-01', value: 70 },
            { date: '2024-02', value: 73 },
            { date: '2024-03', value: 75 },
            { date: '2024-04', value: 78 },
            { date: '2024-05', value: 80 }
          ]
        }
      ],
      operationalKPIs: [
        { 
          name: 'Model Accuracy',
          value: '96%',
          trend: 'up',
          description: 'Overall model accuracy in threat detection',
          target: '98%',
          history: [
            { date: '2024-01', value: 92 },
            { date: '2024-02', value: 93 },
            { date: '2024-03', value: 94 },
            { date: '2024-04', value: 95 },
            { date: '2024-05', value: 96 }
          ]
        },
        { 
          name: 'Response Time',
          value: '150ms',
          trend: 'down',
          description: 'Average response time for analysis',
          target: '100ms',
          history: [
            { date: '2024-01', value: 200 },
            { date: '2024-02', value: 180 },
            { date: '2024-03', value: 170 },
            { date: '2024-04', value: 160 },
            { date: '2024-05', value: 150 }
          ]
        },
        { 
          name: 'Resource Usage',
          value: '70%',
          trend: 'stable',
          description: 'System resource utilization',
          target: '75%',
          history: [
            { date: '2024-01', value: 70 },
            { date: '2024-02', value: 70 },
            { date: '2024-03', value: 70 },
            { date: '2024-04', value: 70 },
            { date: '2024-05', value: 70 }
          ]
        }
      ],
      securityKPIs: [
        { 
          name: 'Threat Detection',
          value: '97%',
          trend: 'up',
          description: 'Percentage of threats detected',
          target: '99%',
          history: [
            { date: '2024-01', value: 94 },
            { date: '2024-02', value: 95 },
            { date: '2024-03', value: 96 },
            { date: '2024-04', value: 96 },
            { date: '2024-05', value: 97 }
          ]
        },
        { 
          name: 'False Positives',
          value: '3%',
          trend: 'down',
          description: 'Rate of false positive alerts',
          target: '2%',
          history: [
            { date: '2024-01', value: 6 },
            { date: '2024-02', value: 5 },
            { date: '2024-03', value: 4 },
            { date: '2024-04', value: 3.5 },
            { date: '2024-05', value: 3 }
          ]
        },
        { 
          name: 'Compliance Score',
          value: '94%',
          trend: 'up',
          description: 'Overall compliance rating',
          target: '96%',
          history: [
            { date: '2024-01', value: 91 },
            { date: '2024-02', value: 92 },
            { date: '2024-03', value: 93 },
            { date: '2024-04', value: 93 },
            { date: '2024-05', value: 94 }
          ]
        }
      ]
    }
  ];

  // Aggregate metrics for all projects
  const aggregateMetrics = {
    totalProjects: projects.length,
    averageModelAccuracy: '95%',
    averageResponseTime: '135ms',
    averageResourceUsage: '68%',
    totalThreatsDetected: '1,234',
    averageComplianceScore: '94%',
    totalCost: '$45,000',
    totalTokens: '1.2M',
    averageLatency: '120ms',
    averageThroughput: '1.5k req/s',
    totalErrors: '45',
    averageUptime: '99.9%',
    totalUsers: '2.5k',
    averageSatisfaction: '4.8/5',
    totalAlerts: '156',
    averageResolutionTime: '15min'
  };

  // Mock data for charts (you can replace with real data)
  const costData = [
    { name: 'Jan', cost: 4000, tokens: 1200000 },
    { name: 'Feb', cost: 3000, tokens: 900000 },
    { name: 'Mar', cost: 5000, tokens: 1500000 },
    { name: 'Apr', cost: 4500, tokens: 1350000 },
    { name: 'May', cost: 6000, tokens: 1800000 },
  ];

  const revenueData = [
    { name: 'ChatGPT', revenue: 12000, users: 5000 },
    { name: 'DALL-E', revenue: 8000, users: 3000 },
    { name: 'Codex', revenue: 15000, users: 6000 },
    { name: 'Whisper', revenue: 5000, users: 2000 },
  ];

  const userData = [
    { name: 'ChatGPT', value: 400, growth: 15 },
    { name: 'DALL-E', value: 300, growth: 20 },
    { name: 'Codex', value: 200, growth: 25 },
    { name: 'Whisper', value: 100, growth: 10 },
  ];

  const performanceData = [
    { name: 'Jan', latency: 200, throughput: 1000, errors: 5 },
    { name: 'Feb', latency: 180, throughput: 1200, errors: 4 },
    { name: 'Mar', latency: 150, throughput: 1500, errors: 3 },
    { name: 'Apr', latency: 160, throughput: 1400, errors: 4 },
    { name: 'May', latency: 140, throughput: 1800, errors: 2 },
  ];

  const securityData = [
    { name: 'Jan', attempts: 100, blocked: 20, threats: 5 },
    { name: 'Feb', attempts: 120, blocked: 25, threats: 4 },
    { name: 'Mar', attempts: 90, blocked: 15, threats: 3 },
    { name: 'Apr', attempts: 110, blocked: 22, threats: 4 },
    { name: 'May', attempts: 130, blocked: 28, threats: 6 },
  ];

  const COLORS = ['#0ea5e9', '#10b981', '#f59e0b', '#ef4444'];

  // Trend data for metrics
  const trendData = {
    accuracy: [
      { date: '2024-01', value: 92 },
      { date: '2024-02', value: 93 },
      { date: '2024-03', value: 94 },
      { date: '2024-04', value: 95 },
      { date: '2024-05', value: 95 }
    ],
    responseTime: [
      { date: '2024-01', value: 150 },
      { date: '2024-02', value: 145 },
      { date: '2024-03', value: 140 },
      { date: '2024-04', value: 135 },
      { date: '2024-05', value: 135 }
    ],
    cost: [
      { date: '2024-01', value: 50000 },
      { date: '2024-02', value: 48000 },
      { date: '2024-03', value: 46000 },
      { date: '2024-04', value: 45000 },
      { date: '2024-05', value: 45000 }
    ]
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header/Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200">
        <div className="w-full mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Brand */}
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-yellow-600">
                <BuildingOfficeIcon className="h-6 w-6 text-white" />
              </div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-gray-900">AIOps Central</h1>
                <span className="px-2 py-1 text-xs font-medium text-yellow-600 bg-yellow-50 rounded-full">Internal</span>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex items-center gap-1">
              <Link
                to="/"
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-600 hover:text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors duration-200"
              >
                <HomeIcon className="h-5 w-5" />
                Home
              </Link>
              <Link
                to="/dashboard"
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-yellow-600 bg-yellow-50 rounded-lg"
              >
                <ChartBarIcon className="h-5 w-5" />
                Dashboard
              </Link>
              <Link
                to="/admin"
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-600 hover:text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors duration-200"
              >
                <Cog6ToothIcon className="h-5 w-5" />
                Admin
              </Link>
            </nav>
          </div>
        </div>
      </header>

      <div className="pt-24 pb-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Project Selection and Controls */}
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <select
                value={selectedProject}
                onChange={(e) => setSelectedProject(e.target.value)}
                className="input w-64"
              >
                <option value="all">All Projects</option>
                {projects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}
                  </option>
                ))}
              </select>
              <select
                value={dateRange}
                onChange={(e) => setDateRange(e.target.value)}
                className="input w-32"
              >
                <option value="7d">Last 7 days</option>
                <option value="30d">Last 30 days</option>
                <option value="90d">Last 90 days</option>
                <option value="1y">Last year</option>
              </select>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setCompareMode(!compareMode)}
                className={`btn ${
                  compareMode ? 'bg-yellow-600 text-white' : 'bg-gray-100 text-gray-600'
                }`}
              >
                Compare Projects
              </button>
              <button
                onClick={() => setShowNewProjectModal(true)}
                className="btn bg-yellow-600 hover:bg-yellow-700 text-white flex items-center gap-2"
              >
                <PlusIcon className="h-5 w-5" />
                Add New Project
              </button>
            </div>
          </div>

          {/* Aggregate Metrics Section */}
          {selectedProject === 'all' && (
            <section className="card">
              <h2 className="text-3xl font-display font-bold text-gray-900 mb-8">Aggregate Metrics</h2>
              
              {/* Quick Stats with Mini Charts */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                <div className="bg-yellow-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600">Total Projects</span>
                    <span className="text-2xl font-bold text-yellow-600">{aggregateMetrics.totalProjects}</span>
                  </div>
                  <div className="h-16">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData.accuracy}>
                        <Line type="monotone" dataKey="value" stroke="#f59e0b" strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="bg-green-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600">Average Accuracy</span>
                    <span className="text-2xl font-bold text-green-600">{aggregateMetrics.averageModelAccuracy}</span>
                  </div>
                  <div className="h-16">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData.accuracy}>
                        <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
                <div className="bg-blue-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600">Total Users</span>
                    <span className="text-2xl font-bold text-blue-600">{aggregateMetrics.totalUsers}</span>
                  </div>
                  <div className="h-16">
              <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={trendData.accuracy}>
                        <Area type="monotone" dataKey="value" stroke="#3b82f6" fill="#3b82f6" fillOpacity={0.2} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>
                <div className="bg-purple-50 rounded-lg p-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-medium text-gray-600">Average Uptime</span>
                    <span className="text-2xl font-bold text-purple-600">{aggregateMetrics.averageUptime}</span>
                  </div>
                  <div className="h-16">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={trendData.accuracy}>
                        <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} dot={false} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </div>

              {/* Main Metrics Grid with Enhanced Cards */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                {/* Performance Overview */}
                <div className="card hover-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-700">Performance Overview</h3>
                    <button className="text-gray-400 hover:text-gray-600">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Response Time</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageResponseTime}</p>
                      </div>
                      <div className="text-green-600">↓ 12%</div>
                    </div>
                    <div className="h-32">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={trendData.responseTime}>
                          <Line type="monotone" dataKey="value" stroke="#0ea5e9" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Throughput</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageThroughput}</p>
                      </div>
                      <div className="text-green-600">↑ 8%</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Resource Usage</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageResourceUsage}</p>
                      </div>
                      <div className="text-gray-600">→</div>
                    </div>
                  </div>
                </div>

                {/* Security Overview with Enhanced Visualization */}
          <div className="card hover-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-700">Security Overview</h3>
                    <button className="text-gray-400 hover:text-gray-600">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Threats Detected</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.totalThreatsDetected}</p>
                      </div>
                      <div className="text-red-600">↑ 5%</div>
                    </div>
                    <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={securityData}>
                          <Bar dataKey="threats" fill="#ef4444" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Compliance Score</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageComplianceScore}</p>
                      </div>
                      <div className="text-green-600">↑ 2%</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Total Alerts</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.totalAlerts}</p>
                      </div>
                      <div className="text-yellow-600">↑ 3%</div>
                    </div>
                  </div>
                </div>

                {/* Cost Overview with Enhanced Visualization */}
                <div className="card hover-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-700">Cost Overview</h3>
                    <button className="text-gray-400 hover:text-gray-600">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Total Cost</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.totalCost}</p>
                      </div>
                      <div className="text-green-600">↓ 15%</div>
                    </div>
                    <div className="h-32">
                      <ResponsiveContainer width="100%" height="100%">
                        <AreaChart data={trendData.cost}>
                          <Area type="monotone" dataKey="value" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.2} />
                        </AreaChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Token Usage</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.totalTokens}</p>
                      </div>
                      <div className="text-yellow-600">↑ 10%</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Cost per Token</span>
                        <p className="text-2xl font-bold text-gray-900">$0.037</p>
                      </div>
                      <div className="text-green-600">↓ 5%</div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Additional Metrics with Enhanced Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
                {/* User Experience with Enhanced Visualization */}
                <div className="card hover-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-700">User Experience</h3>
                    <button className="text-gray-400 hover:text-gray-600">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">User Satisfaction</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageSatisfaction}</p>
                      </div>
                      <div className="text-green-600">↑ 5%</div>
                    </div>
                    <div className="h-32">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={trendData.accuracy}>
                          <Line type="monotone" dataKey="value" stroke="#10b981" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Error Rate</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.totalErrors}</p>
                      </div>
                      <div className="text-green-600">↓ 8%</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Resolution Time</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageResolutionTime}</p>
                      </div>
                      <div className="text-green-600">↓ 12%</div>
                    </div>
            </div>
          </div>

                {/* System Health with Enhanced Visualization */}
          <div className="card hover-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xl font-semibold text-gray-700">System Health</h3>
                    <button className="text-gray-400 hover:text-gray-600">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                      </svg>
                    </button>
                  </div>
                  <div className="space-y-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">System Uptime</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageUptime}</p>
                      </div>
                      <div className="text-green-600">→</div>
                    </div>
                    <div className="h-32">
                      <ResponsiveContainer width="100%" height="100%">
                        <LineChart data={trendData.accuracy}>
                          <Line type="monotone" dataKey="value" stroke="#8b5cf6" strokeWidth={2} />
                        </LineChart>
                      </ResponsiveContainer>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Average Latency</span>
                        <p className="text-2xl font-bold text-gray-900">{aggregateMetrics.averageLatency}</p>
                      </div>
                      <div className="text-green-600">↓ 10%</div>
                    </div>
                    <div className="flex justify-between items-center">
                      <div>
                        <span className="text-gray-600">Resource Efficiency</span>
                        <p className="text-2xl font-bold text-gray-900">92%</p>
                      </div>
                      <div className="text-green-600">↑ 3%</div>
                    </div>
                  </div>
                </div>
              </div>
            </section>
          )}

          {/* Project-specific KPIs */}
          {selectedProject !== 'all' && (
            <>
              {/* Project Header with Enhanced Design */}
              <div className="card mb-8 bg-gradient-to-r from-yellow-50 to-yellow-100 border border-yellow-200">
                <div className="flex items-center justify-between p-6">
                  <div>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex items-center justify-center w-12 h-12 rounded-lg bg-yellow-600">
                        <BuildingOfficeIcon className="h-7 w-7 text-white" />
                      </div>
                      <h2 className="text-3xl font-display font-bold text-gray-900">
                        {projects.find(p => p.id === selectedProject)?.name}
                      </h2>
                    </div>
                    <p className="text-gray-600 mt-2 text-lg">
                      {projects.find(p => p.id === selectedProject)?.description}
                    </p>
                  </div>
                  <div className="flex items-center gap-4">
                    <button className="btn bg-yellow-600 hover:bg-yellow-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Export Report
                    </button>
                    <button className="btn bg-white hover:bg-gray-50 text-gray-600 border border-gray-200 flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                      </svg>
                      Share
                    </button>
                  </div>
                </div>
              </div>

              {/* Business KPIs Section with Enhanced Design */}
              <section className="card">
                <div className="flex items-center justify-between mb-8 p-6 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-blue-100">
                      <ChartBarIcon className="h-6 w-6 text-blue-600" />
                    </div>
                    <h2 className="text-2xl font-display font-bold text-gray-900">Business KPIs</h2>
                  </div>
                  <div className="flex space-x-2">
                    <button className="btn bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Export
                    </button>
                    <button className="btn bg-gray-600 hover:bg-gray-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                      </svg>
                      Filter
                    </button>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-6">
                  {projects.find(p => p.id === selectedProject)?.businessKPIs.map((kpi, index) => (
                    <div key={index} className="card hover-card bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200">
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-gray-700">{kpi.name}</h3>
                          <button className="text-gray-400 hover:text-gray-600">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                            </svg>
                          </button>
                        </div>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-3xl font-bold text-gray-900">{kpi.value}</span>
                              <p className="text-sm text-gray-500 mt-1">{kpi.description}</p>
                            </div>
                            <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                              kpi.trend === 'up' ? 'bg-green-100 text-green-700' :
                              kpi.trend === 'down' ? 'bg-red-100 text-red-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {kpi.trend === 'up' ? '↑' : kpi.trend === 'down' ? '↓' : '→'}
                              <span className="text-xs">
                                {kpi.trend === 'up' ? 'Positive' : kpi.trend === 'down' ? 'Negative' : 'Stable'}
                              </span>
                            </div>
                          </div>
                          <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                              {kpi.name.includes('Efficiency') || kpi.name.includes('Reduction') ? (
                                // Bar Chart for Efficiency and Reduction metrics
                                <BarChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Bar 
                                    dataKey="value" 
                                    fill={`url(#gradient-${index})`}
                                    radius={[4, 4, 0, 0]}
                                  />
                                </BarChart>
                              ) : kpi.name.includes('Time') || kpi.name.includes('Response') ? (
                                // Area Chart for Time and Response metrics
                                <AreaChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} 
                                    fill={`url(#gradient-${index})`} 
                                  />
                                </AreaChart>
                              ) : kpi.name.includes('Accuracy') || kpi.name.includes('Score') ? (
                                // Pie Chart for Accuracy and Score metrics
                <PieChart>
                  <Pie
                                    data={[
                                      { name: 'Current', value: parseInt(kpi.value) },
                                      { name: 'Remaining', value: 100 - parseInt(kpi.value) }
                                    ]}
                    cx="50%"
                    cy="50%"
                                    innerRadius={30}
                                    outerRadius={40}
                                    paddingAngle={2}
                    dataKey="value"
                  >
                                    <Cell fill={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} />
                                    <Cell fill="#e5e7eb" />
                  </Pie>
                </PieChart>
                              ) : kpi.name.includes('Usage') ? (
                                // Radial Bar Chart for Usage metrics
                                <RadialBarChart
                                  innerRadius="60%"
                                  outerRadius="100%"
                                  data={[
                                    {
                                      name: 'Usage',
                                      value: parseInt(kpi.value),
                                      fill: kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'
                                    }
                                  ]}
                                  startAngle={180}
                                  endAngle={0}
                                >
                                  <RadialBar
                                    dataKey="value"
                                    background
                                  />
                                </RadialBarChart>
                              ) : (
                                // Default Line Chart for other metrics
                                <LineChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Line 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} 
                                    strokeWidth={2} 
                                    dot={false}
                                  />
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    fill={`url(#gradient-${index})`} 
                                    stroke="none"
                                  />
                                </LineChart>
                              )}
              </ResponsiveContainer>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Target:</span>
                              <span className="font-medium text-gray-900">{kpi.target}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Last 30 days</span>
                            </div>
                          </div>
            </div>
          </div>
                    </div>
                  ))}
        </div>
      </section>

              {/* Operational KPIs Section with Enhanced Design */}
              <section className="card mt-8">
                <div className="flex items-center justify-between mb-8 p-6 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-purple-100">
                      <CpuChipIcon className="h-6 w-6 text-purple-600" />
                    </div>
                    <h2 className="text-2xl font-display font-bold text-gray-900">Operational KPIs</h2>
                  </div>
          <div className="flex space-x-2">
                    <button className="btn bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Export
                    </button>
                    <button className="btn bg-gray-600 hover:bg-gray-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                      </svg>
                      Filter
                    </button>
          </div>
        </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-6">
                  {projects.find(p => p.id === selectedProject)?.operationalKPIs.map((kpi, index) => (
                    <div key={index} className="card hover-card bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200">
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-gray-700">{kpi.name}</h3>
                          <button className="text-gray-400 hover:text-gray-600">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                            </svg>
                          </button>
                        </div>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-3xl font-bold text-gray-900">{kpi.value}</span>
                              <p className="text-sm text-gray-500 mt-1">{kpi.description}</p>
                            </div>
                            <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                              kpi.trend === 'up' ? 'bg-green-100 text-green-700' :
                              kpi.trend === 'down' ? 'bg-red-100 text-red-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {kpi.trend === 'up' ? '↑' : kpi.trend === 'down' ? '↓' : '→'}
                              <span className="text-xs">
                                {kpi.trend === 'up' ? 'Positive' : kpi.trend === 'down' ? 'Negative' : 'Stable'}
                              </span>
            </div>
          </div>
                          <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                              {kpi.name.includes('Efficiency') || kpi.name.includes('Reduction') ? (
                                // Bar Chart for Efficiency and Reduction metrics
                                <BarChart data={kpi.history}>
                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                    </linearGradient>
                                  </defs>
                                  <Bar 
                                    dataKey="value" 
                                    fill={`url(#gradient-${index})`}
                                    radius={[4, 4, 0, 0]}
                                  />
                                </BarChart>
                              ) : kpi.name.includes('Time') || kpi.name.includes('Response') ? (
                                // Area Chart for Time and Response metrics
                                <AreaChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} 
                                    fill={`url(#gradient-${index})`} 
                                  />
                </AreaChart>
                              ) : kpi.name.includes('Accuracy') || kpi.name.includes('Score') ? (
                                // Pie Chart for Accuracy and Score metrics
                                <PieChart>
                                  <Pie
                                    data={[
                                      { name: 'Current', value: parseInt(kpi.value) },
                                      { name: 'Remaining', value: 100 - parseInt(kpi.value) }
                                    ]}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={30}
                                    outerRadius={40}
                                    paddingAngle={2}
                                    dataKey="value"
                                  >
                                    <Cell fill={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} />
                                    <Cell fill="#e5e7eb" />
                                  </Pie>
                                </PieChart>
                              ) : kpi.name.includes('Usage') ? (
                                // Radial Bar Chart for Usage metrics
                                <RadialBarChart
                                  innerRadius="60%"
                                  outerRadius="100%"
                                  data={[
                                    {
                                      name: 'Usage',
                                      value: parseInt(kpi.value),
                                      fill: kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'
                                    }
                                  ]}
                                  startAngle={180}
                                  endAngle={0}
                                >
                                  <RadialBar
                                    dataKey="value"
                                    background
                                  />
                                </RadialBarChart>
                              ) : (
                                // Default Line Chart for other metrics
                                <LineChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Line 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} 
                                    strokeWidth={2} 
                                    dot={false}
                                  />
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    fill={`url(#gradient-${index})`} 
                                    stroke="none"
                                  />
                                </LineChart>
                              )}
              </ResponsiveContainer>
                          </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Target:</span>
                              <span className="font-medium text-gray-900">{kpi.target}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Last 30 days</span>
                            </div>
                          </div>
            </div>
          </div>
                    </div>
                  ))}
        </div>
      </section>

              {/* Security KPIs Section with Enhanced Design */}
              <section className="card mt-8">
                <div className="flex items-center justify-between mb-8 p-6 border-b border-gray-200">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-red-100">
                      <ShieldCheckIcon className="h-6 w-6 text-red-600" />
                    </div>
                    <h2 className="text-2xl font-display font-bold text-gray-900">Security KPIs</h2>
                  </div>
          <div className="flex space-x-2">
                    <button className="btn bg-red-600 hover:bg-red-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                      </svg>
                      Export
                    </button>
                    <button className="btn bg-gray-600 hover:bg-gray-700 text-white flex items-center gap-2">
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                      </svg>
                      Filter
                    </button>
          </div>
        </div>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-8 p-6">
                  {projects.find(p => p.id === selectedProject)?.securityKPIs.map((kpi, index) => (
                    <div key={index} className="card hover-card bg-white border border-gray-200 rounded-xl shadow-sm hover:shadow-md transition-shadow duration-200">
                      <div className="p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h3 className="text-lg font-semibold text-gray-700">{kpi.name}</h3>
                          <button className="text-gray-400 hover:text-gray-600">
                            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
                            </svg>
                          </button>
                        </div>
                        <div className="space-y-4">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-3xl font-bold text-gray-900">{kpi.value}</span>
                              <p className="text-sm text-gray-500 mt-1">{kpi.description}</p>
                            </div>
                            <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                              kpi.trend === 'up' ? 'bg-green-100 text-green-700' :
                              kpi.trend === 'down' ? 'bg-red-100 text-red-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {kpi.trend === 'up' ? '↑' : kpi.trend === 'down' ? '↓' : '→'}
                              <span className="text-xs">
                                {kpi.trend === 'up' ? 'Positive' : kpi.trend === 'down' ? 'Negative' : 'Stable'}
                              </span>
            </div>
          </div>
                          <div className="h-32">
              <ResponsiveContainer width="100%" height="100%">
                              {kpi.name.includes('Efficiency') || kpi.name.includes('Reduction') ? (
                                // Bar Chart for Efficiency and Reduction metrics
                                <BarChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Bar 
                                    dataKey="value" 
                                    fill={`url(#gradient-${index})`}
                                    radius={[4, 4, 0, 0]}
                                  />
                </BarChart>
                              ) : kpi.name.includes('Time') || kpi.name.includes('Response') ? (
                                // Area Chart for Time and Response metrics
                                <AreaChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} 
                                    fill={`url(#gradient-${index})`} 
                                  />
                                </AreaChart>
                              ) : kpi.name.includes('Accuracy') || kpi.name.includes('Score') ? (
                                // Pie Chart for Accuracy and Score metrics
                                <PieChart>
                                  <Pie
                                    data={[
                                      { name: 'Current', value: parseInt(kpi.value) },
                                      { name: 'Remaining', value: 100 - parseInt(kpi.value) }
                                    ]}
                                    cx="50%"
                                    cy="50%"
                                    innerRadius={30}
                                    outerRadius={40}
                                    paddingAngle={2}
                                    dataKey="value"
                                  >
                                    <Cell fill={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} />
                                    <Cell fill="#e5e7eb" />
                                  </Pie>
                                </PieChart>
                              ) : kpi.name.includes('Usage') ? (
                                // Radial Bar Chart for Usage metrics
                                <RadialBarChart
                                  innerRadius="60%"
                                  outerRadius="100%"
                                  data={[
                                    {
                                      name: 'Usage',
                                      value: parseInt(kpi.value),
                                      fill: kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'
                                    }
                                  ]}
                                  startAngle={180}
                                  endAngle={0}
                                >
                                  <RadialBar
                                    dataKey="value"
                                    background
                                  />
                                </RadialBarChart>
                              ) : (
                                // Default Line Chart for other metrics
                                <LineChart data={kpi.history}>
                                  <defs>
                                    <linearGradient id={`gradient-${index}`} x1="0" y1="0" x2="0" y2="1">
                                      <stop offset="5%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0.3}/>
                                      <stop offset="95%" stopColor={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} stopOpacity={0}/>
                                    </linearGradient>
                                  </defs>
                                  <Line 
                                    type="monotone" 
                                    dataKey="value" 
                                    stroke={kpi.trend === 'up' ? '#10b981' : kpi.trend === 'down' ? '#ef4444' : '#6b7280'} 
                                    strokeWidth={2} 
                                    dot={false}
                                  />
                                  <Area 
                                    type="monotone" 
                                    dataKey="value" 
                                    fill={`url(#gradient-${index})`} 
                                    stroke="none"
                                  />
                                </LineChart>
                              )}
              </ResponsiveContainer>
            </div>
                          <div className="flex items-center justify-between text-sm">
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Target:</span>
                              <span className="font-medium text-gray-900">{kpi.target}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <span className="text-gray-500">Last 30 days</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            </>
          )}
        </div>
      </div>

      {/* New Project Modal */}
      {showNewProjectModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-2xl w-full">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">Add New Project</h2>
            <form className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Project Name</label>
                <input type="text" className="input w-full" placeholder="Enter project name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea className="input w-full" rows={3} placeholder="Enter project description"></textarea>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Business KPIs</label>
                <div className="space-y-2">
                  <input type="text" className="input w-full" placeholder="Enter KPI name" />
                  <input type="text" className="input w-full" placeholder="Enter KPI value" />
                </div>
              </div>
              <div className="flex justify-end gap-4">
                <button
                  type="button"
                  onClick={() => setShowNewProjectModal(false)}
                  className="btn bg-gray-600 hover:bg-gray-700 text-white"
                >
                  Cancel
                </button>
                <button type="submit" className="btn bg-yellow-600 hover:bg-yellow-700 text-white">
                  Create Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default Dashboard; 