import { Link } from 'react-router-dom';
import { ChartBarIcon, ShieldCheckIcon, CpuChipIcon, UserGroupIcon, ArrowRightIcon, CheckCircleIcon, BuildingOfficeIcon, FolderIcon, KeyIcon, SparklesIcon, HomeIcon, ChartBarIcon as ChartIcon, Cog6ToothIcon } from '@heroicons/react/24/outline';

const Home = () => {
  const features = [
    {
      icon: ChartBarIcon,
      title: 'Business Metrics',
      description: 'Comprehensive business intelligence and financial tracking for all GenAI applications.',
      highlights: [
        'Cost per token analysis',
        'ROI tracking',
        'Usage-based billing',
        'Budget monitoring'
      ],
      metrics: [
        { label: 'Monthly Cost', value: '$45,000', trend: 'down' },
        { label: 'ROI', value: '320%', trend: 'up' },
        { label: 'Cost Efficiency', value: '92%', trend: 'up' }
      ]
    },
    {
      icon: CpuChipIcon,
      title: 'Operational Metrics',
      description: 'Real-time operational performance monitoring and optimization of GenAI infrastructure.',
      highlights: [
        'System performance',
        'Resource utilization',
        'Throughput monitoring',
        'Error rate tracking'
      ],
      metrics: [
        { label: 'System Uptime', value: '99.99%', trend: 'stable' },
        { label: 'Response Time', value: '45ms', trend: 'down' },
        { label: 'Error Rate', value: '0.1%', trend: 'down' }
      ]
    },
    {
      icon: UserGroupIcon,
      title: 'Human Feedback Loop',
      description: 'Track and analyze user feedback and satisfaction metrics for continuous improvement.',
      highlights: [
        'User satisfaction',
        'Feedback analysis',
        'Quality metrics',
        'Improvement tracking'
      ],
      metrics: [
        { label: 'User Satisfaction', value: '4.8/5', trend: 'up' },
        { label: 'Feedback Score', value: '92%', trend: 'up' },
        { label: 'Quality Rating', value: '95%', trend: 'stable' }
      ]
    },
    {
      icon: ShieldCheckIcon,
      title: 'Observability',
      description: 'Comprehensive observability platform for deep insights into GenAI application behavior.',
      highlights: [
        'Log analysis',
        'Trace monitoring',
        'Metrics collection',
        'Anomaly detection'
      ],
      metrics: [
        { label: 'Log Coverage', value: '100%', trend: 'stable' },
        { label: 'Trace Success', value: '99.9%', trend: 'up' },
        { label: 'Alert Accuracy', value: '98%', trend: 'up' }
      ]
    },
    {
      icon: ChartBarIcon,
      title: 'Monitoring & KPI Tracking',
      description: 'Real-time monitoring and KPI tracking for all critical aspects of GenAI operations.',
      highlights: [
        'Real-time alerts',
        'KPI dashboards',
        'Performance tracking',
        'Health monitoring'
      ],
      metrics: [
        { label: 'Alert Response', value: '5min', trend: 'down' },
        { label: 'KPI Coverage', value: '100%', trend: 'stable' },
        { label: 'Health Score', value: '98%', trend: 'up' }
      ]
    },
    {
      icon: CpuChipIcon,
      title: 'Model Monitoring',
      description: 'Comprehensive monitoring of AI model performance, accuracy, and resource utilization.',
      highlights: [
        'Model accuracy tracking',
        'Resource utilization',
        'Performance metrics',
        'Drift detection'
      ],
      metrics: [
        { label: 'Model Accuracy', value: '98.5%', trend: 'up' },
        { label: 'Token Usage', value: '1.2M', trend: 'up' },
        { label: 'Drift Score', value: '0.2%', trend: 'down' }
      ]
    }
  ];

  const benefits = [
    {
      title: 'Enterprise-Grade Monitoring',
      description: 'Built with enterprise security and compliance standards in mind, ensuring your GenAI applications meet the highest security requirements.',
      icon: CheckCircleIcon
    },
    {
      title: 'Real-time Analytics',
      description: 'Advanced analytics and reporting capabilities that provide deep insights into your GenAI applications performance and usage.',
      icon: CheckCircleIcon
    },
    {
      title: 'Proactive Intelligence',
      description: 'AI-powered anomaly detection and predictive analytics to prevent issues before they impact your business.',
      icon: CheckCircleIcon
    },
    {
      title: 'Comprehensive Oversight',
      description: 'Complete visibility and control over your GenAI applications with detailed monitoring and management tools.',
      icon: CheckCircleIcon
    },
  ];

  const projectCards = [
    {
      icon: FolderIcon,
      title: 'Project Overview',
      description: 'Comprehensive dashboard for each GenAI project with key metrics, performance indicators, and real-time monitoring.',
      features: [
        'Project health status',
        'Resource utilization',
        'Cost tracking',
        'Performance metrics'
      ],
      kpis: [
        { label: 'Health Score', value: '98%', trend: 'up' },
        { label: 'Resource Usage', value: '75%', trend: 'stable' },
        { label: 'Cost Efficiency', value: '92%', trend: 'up' }
      ]
    },
    {
      icon: ChartBarIcon,
      title: 'Project Analytics',
      description: 'Detailed analytics and reporting for each GenAI project with customizable KPIs and metrics.',
      features: [
        'Custom KPI dashboards',
        'Trend analysis',
        'Performance reports',
        'Resource optimization'
      ],
      kpis: [
        { label: 'Response Time', value: '45ms', trend: 'down' },
        { label: 'Throughput', value: '1.2k req/s', trend: 'up' },
        { label: 'Error Rate', value: '0.1%', trend: 'down' }
      ]
    },
    {
      icon: ShieldCheckIcon,
      title: 'Access Control',
      description: 'Granular access control and permissions management for each GenAI project.',
      features: [
        'Role-based access',
        'Permission settings',
        'User management',
        'Security policies'
      ],
      kpis: [
        { label: 'Access Requests', value: '25', trend: 'down' },
        { label: 'Compliance', value: '100%', trend: 'stable' },
        { label: 'Security Score', value: '95%', trend: 'up' }
      ]
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header/Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200">
        <div className="w-full mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Brand */}
            <div className="flex items-center gap-3">
              <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-yellow-600">
                <BuildingOfficeIcon className="h-6 w-6 text-white" />
              </div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl font-bold text-gray-900">AIOps Central</h1>
                <span className="px-2 py-1 text-xs font-medium text-yellow-600 bg-yellow-50 rounded-full">Internal</span>
              </div>
            </div>

            {/* Navigation */}
            <nav className="flex items-center gap-1">
              <Link
                to="/"
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-yellow-600 bg-yellow-50 rounded-lg"
              >
                <HomeIcon className="h-5 w-5" />
                Home
              </Link>
              <Link
                to="/dashboard"
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-600 hover:text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors duration-200"
              >
                <ChartIcon className="h-5 w-5" />
                Dashboard
              </Link>
              <Link
                to="/admin"
                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-600 hover:text-yellow-600 hover:bg-yellow-50 rounded-lg transition-colors duration-200"
              >
                <Cog6ToothIcon className="h-5 w-5" />
                Admin
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-yellow-50 via-white to-yellow-50"></div>
        <div className="absolute inset-0 bg-grid-pattern opacity-5"></div>
        <div className="absolute top-0 right-0 w-1/3 h-1/3 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-1/3 h-1/3 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        
        <div className="w-full mx-auto relative">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Content */}
            <div className="text-left">
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-yellow-50 text-yellow-600 font-medium mb-6">
                <SparklesIcon className="h-5 w-5" />
                <span>Wells Fargo Internal Platform</span>
              </div>
              
              <h1 className="text-4xl md:text-5xl font-display font-bold mb-6 text-gray-900 leading-tight">
                Your Central Hub for <span className="text-yellow-600">Internal GenAI Operations</span>
              </h1>
              
              <p className="text-lg text-gray-600 mb-8 max-w-xl">
                Comprehensive monitoring and management platform for all Wells Fargo GenAI applications. From chatbots to document processing, ensure security, performance, and compliance across our entire AI ecosystem.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/dashboard"
                  className="btn bg-yellow-600 hover:bg-yellow-700 text-white text-lg flex items-center justify-center gap-2 px-8 py-3"
                >
                  Access Dashboard
                  <ArrowRightIcon className="h-5 w-5" />
                </Link>
                <Link
                  to="/admin"
                  className="btn bg-gray-600 hover:bg-gray-700 text-white text-lg px-8 py-3"
                >
                  Admin Portal
                </Link>
              </div>

              <div className="mt-12 flex flex-wrap gap-6 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <CheckCircleIcon className="h-5 w-5 text-yellow-600" />
                  <span>Internal Access Only</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircleIcon className="h-5 w-5 text-yellow-600" />
                  <span>24/7 Support</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckCircleIcon className="h-5 w-5 text-yellow-600" />
                  <span>Compliance Ready</span>
                </div>
              </div>
            </div>

            {/* Right Column - Visual */}
            <div className="relative hidden lg:block">
              <div className="relative z-10">
                <div className="relative bg-white rounded-lg shadow-lg p-6 border border-gray-200">
                  <div className="flex items-center justify-between mb-6">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 rounded-full bg-red-500"></div>
                      <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
                      <div className="w-3 h-3 rounded-full bg-green-500"></div>
                    </div>
                    <div className="text-sm text-gray-500">AIOps Central Dashboard</div>
                  </div>
                  
                  {/* Sample KPIs */}
                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-yellow-50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">Model Performance</span>
                        <span className="text-xs text-green-600">98.5%</span>
                      </div>
                      <div className="h-2 bg-yellow-100 rounded-full">
                        <div className="h-2 bg-yellow-600 rounded-full" style={{ width: '98.5%' }}></div>
                      </div>
                    </div>
                    <div className="bg-yellow-50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">API Latency</span>
                        <span className="text-xs text-green-600">45ms</span>
                      </div>
                      <div className="h-2 bg-yellow-100 rounded-full">
                        <div className="h-2 bg-yellow-600 rounded-full" style={{ width: '85%' }}></div>
                      </div>
                    </div>
                  </div>

                  {/* Sample Charts */}
                  <div className="space-y-4 mb-6">
                    <div className="h-24 bg-gray-50 rounded-lg p-3">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-gray-600">Token Usage</span>
                        <span className="text-xs text-gray-500">Last 24h</span>
                      </div>
                      <div className="flex items-end h-12 gap-1">
                        <div className="w-1/12 h-8 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-10 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-6 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-9 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-11 bg-yellow-600 rounded-t"></div>
                        <div className="w-1/12 h-7 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-8 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-10 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-6 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-9 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-11 bg-yellow-100 rounded-t"></div>
                        <div className="w-1/12 h-7 bg-yellow-100 rounded-t"></div>
                      </div>
                    </div>
                  </div>

                  {/* Sample Alerts */}
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 p-2 bg-red-50 rounded">
                      <div className="w-2 h-2 rounded-full bg-red-500"></div>
                      <span className="text-sm text-gray-600">High latency detected in GPT-4 model</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-yellow-50 rounded">
                      <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
                      <span className="text-sm text-gray-600">Token usage approaching limit</span>
                    </div>
                    <div className="flex items-center gap-2 p-2 bg-green-50 rounded">
                      <div className="w-2 h-2 rounded-full bg-green-500"></div>
                      <span className="text-sm text-gray-600">All systems operational</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Project Management Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="w-full mx-auto relative">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-display font-bold mb-4 text-gray-900">Project Management</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Monitor and manage all your internal GenAI projects with comprehensive KPIs and analytics
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projectCards.map((card, index) => (
              <div
                key={card.title}
                className="card hover-card group transform hover:-translate-y-1 transition-all duration-300"
              >
                <div className="p-4 bg-yellow-50 rounded-lg inline-block mb-4 group-hover:bg-yellow-100 transition-colors duration-300">
                  <card.icon className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-900">{card.title}</h3>
                <p className="text-gray-600 mb-6">{card.description}</p>
                
                {/* KPIs Section */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {card.kpis.map((kpi, i) => (
                    <div key={i} className="bg-gray-50 rounded-lg p-3">
                      <div className="text-sm text-gray-500 mb-1">{kpi.label}</div>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-semibold text-gray-900">{kpi.value}</span>
                        <span className={`text-sm ${
                          kpi.trend === 'up' ? 'text-green-600' :
                          kpi.trend === 'down' ? 'text-red-600' :
                          'text-gray-600'
                        }`}>
                          {kpi.trend === 'up' ? '↑' : kpi.trend === 'down' ? '↓' : '→'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <ul className="space-y-2">
                  {card.features.map((feature, i) => (
                    <li key={i} className="flex items-center gap-2 text-gray-600">
                      <CheckCircleIcon className="h-5 w-5 text-yellow-600" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-gray-50 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="w-full mx-auto relative">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-display font-bold mb-4 text-gray-900">Internal Features</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Comprehensive monitoring and management tools for Wells Fargo GenAI applications
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div
                key={feature.title}
                className="card hover-card group transform hover:-translate-y-1 transition-all duration-300"
              >
                <div className="p-4 bg-yellow-50 rounded-lg inline-block mb-4 group-hover:bg-yellow-100 transition-colors duration-300">
                  <feature.icon className="h-8 w-8 text-yellow-600" />
                </div>
                <h3 className="text-xl font-bold mb-4 text-gray-900">{feature.title}</h3>
                <p className="text-gray-600 mb-6">{feature.description}</p>
                
                {/* Metrics Section */}
                <div className="grid grid-cols-3 gap-4 mb-6">
                  {feature.metrics.map((metric, i) => (
                    <div key={i} className="bg-gray-50 rounded-lg p-3">
                      <div className="text-sm text-gray-500 mb-1">{metric.label}</div>
                      <div className="flex items-center justify-between">
                        <span className="text-lg font-semibold text-gray-900">{metric.value}</span>
                        <span className={`text-sm ${
                          metric.trend === 'up' ? 'text-green-600' :
                          metric.trend === 'down' ? 'text-red-600' :
                          'text-gray-600'
                        }`}>
                          {metric.trend === 'up' ? '↑' : metric.trend === 'down' ? '↓' : '→'}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <ul className="space-y-2">
                  {feature.highlights.map((highlight, i) => (
                    <li key={i} className="flex items-center gap-2 text-gray-600">
                      <CheckCircleIcon className="h-5 w-5 text-yellow-600" />
                      <span>{highlight}</span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-white relative overflow-hidden">
        <div className="absolute top-0 right-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="w-full mx-auto relative">
          <div className="text-center mb-12">
            <h2 className="text-2xl font-display font-bold mb-4 text-gray-900">Internal Benefits</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Trusted by Wells Fargo teams for secure and efficient GenAI monitoring
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {benefits.map((benefit, index) => (
              <div
                key={benefit.title}
                className="card hover-card group transform hover:-translate-y-1 transition-all duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-yellow-50 rounded-lg group-hover:bg-yellow-100 transition-colors duration-300">
                    <benefit.icon className="h-6 w-6 text-yellow-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold mb-4 text-gray-900">{benefit.title}</h3>
                    <p className="text-gray-600">{benefit.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Indicators */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 bg-gray-50 relative overflow-hidden">
        <div className="absolute top-0 left-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-1/4 h-1/4 bg-yellow-100/30 rounded-full filter blur-3xl"></div>
        <div className="w-full mx-auto relative">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 items-center justify-items-center">
            <div className="text-center p-6 rounded-lg bg-white shadow-soft hover:shadow-hover transition-all duration-300 transform hover:-translate-y-1">
              <p className="text-3xl font-bold text-yellow-600 mb-2">98.5%</p>
              <p className="text-gray-600 font-medium">Model Accuracy</p>
            </div>
            <div className="text-center p-6 rounded-lg bg-white shadow-soft hover:shadow-hover transition-all duration-300 transform hover:-translate-y-1">
              <p className="text-3xl font-bold text-yellow-600 mb-2">45ms</p>
              <p className="text-gray-600 font-medium">Avg Response Time</p>
            </div>
            <div className="text-center p-6 rounded-lg bg-white shadow-soft hover:shadow-hover transition-all duration-300 transform hover:-translate-y-1">
              <p className="text-3xl font-bold text-yellow-600 mb-2">1.2M</p>
              <p className="text-gray-600 font-medium">Tokens Processed</p>
            </div>
            <div className="text-center p-6 rounded-lg bg-white shadow-soft hover:shadow-hover transition-all duration-300 transform hover:-translate-y-1">
              <p className="text-3xl font-bold text-yellow-600 mb-2">4.8/5</p>
              <p className="text-gray-600 font-medium">User Satisfaction</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home; 