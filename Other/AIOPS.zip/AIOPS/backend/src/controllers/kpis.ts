import { Request, Response, NextFunction } from 'express';
import { AppError } from '../middleware/errorHandler';
import { MockDataStore } from '../utils/mockData';

export const getKPIs = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const kpis = dataStore.getKPIs();

    res.status(200).json({
      status: 'success',
      data: {
        kpis,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getKPIById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const kpi = dataStore.getKPIById(req.params.id);

    if (!kpi) {
      return next(new AppError('KPI not found', 404));
    }

    res.status(200).json({
      status: 'success',
      data: {
        kpi,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const createKPI = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const kpi = dataStore.createKPI(req.body);

    res.status(201).json({
      status: 'success',
      data: {
        kpi,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const updateKPI = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const kpi = dataStore.updateKPI(req.params.id, req.body);

    if (!kpi) {
      return next(new AppError('KPI not found', 404));
    }

    res.status(200).json({
      status: 'success',
      data: {
        kpi,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const deleteKPI = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const success = dataStore.deleteKPI(req.params.id);

    if (!success) {
      return next(new AppError('KPI not found', 404));
    }

    res.status(204).json({
      status: 'success',
      data: null,
    });
  } catch (error) {
    next(error);
  }
};

export const getKPIsByType = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const { type } = req.params;
    const dataStore = MockDataStore.getInstance();
    const kpis = dataStore.getKPIsByType(type);

    res.status(200).json({
      status: 'success',
      data: {
        kpis,
      },
    });
  } catch (error) {
    next(error);
  }
}; 