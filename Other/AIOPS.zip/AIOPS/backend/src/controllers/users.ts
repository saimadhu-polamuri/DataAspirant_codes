import { Request, Response, NextFunction } from 'express';
import { AppError } from '../middleware/errorHandler';
import { MockDataStore } from '../utils/mockData';

export const getUsers = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const users = dataStore.getUsers();

    res.status(200).json({
      status: 'success',
      data: {
        users,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const getUserById = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const user = dataStore.getUserById(req.params.id);

    if (!user) {
      return next(new AppError('User not found', 404));
    }

    res.status(200).json({
      status: 'success',
      data: {
        user,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const updateUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    // Prevent password update through this route
    if (req.body.password) {
      return next(new AppError('This route is not for password updates', 400));
    }

    const dataStore = MockDataStore.getInstance();
    const user = dataStore.updateUser(req.params.id, req.body);

    if (!user) {
      return next(new AppError('User not found', 404));
    }

    res.status(200).json({
      status: 'success',
      data: {
        user,
      },
    });
  } catch (error) {
    next(error);
  }
};

export const deleteUser = async (
  req: Request,
  res: Response,
  next: NextFunction
) => {
  try {
    const dataStore = MockDataStore.getInstance();
    const success = dataStore.deleteUser(req.params.id);

    if (!success) {
      return next(new AppError('User not found', 404));
    }

    res.status(204).json({
      status: 'success',
      data: null,
    });
  } catch (error) {
    next(error);
  }
}; 