import express from 'express';
import {
  getKPIs,
  getKPIById,
  createKPI,
  updateKPI,
  deleteKPI,
  getKPIsByType,
} from '../controllers/kpis';
import { protect } from '../middleware/auth';

const router = express.Router();

// Protected routes
router.use(protect);

router.route('/')
  .get(getKPIs)
  .post(createKPI);

router.route('/:id')
  .get(getKPIById)
  .put(updateKPI)
  .delete(deleteKPI);

router.get('/type/:type', getKPIsByType);

export default router; 