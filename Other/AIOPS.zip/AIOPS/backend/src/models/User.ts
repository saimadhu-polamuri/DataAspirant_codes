export interface IUser {
  _id: string;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'user';
  createdAt: Date;
  updatedAt: Date;
  comparePassword?(candidatePassword: string): Promise<boolean>;
}

// Mock password comparison
export const comparePassword = async (password: string, hashedPassword: string): Promise<boolean> => {
  return password === hashedPassword;
}; 