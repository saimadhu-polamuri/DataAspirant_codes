export interface IKPI {
  _id: string;
  type: 'business' | 'operational' | 'feedback' | 'observability' | 'security';
  name: string;
  value: number;
  timestamp: Date;
  metadata: Record<string, any>;
  createdAt: Date;
  updatedAt: Date;
}

const kpiSchema = new mongoose.Schema(
  {
    type: {
      type: String,
      required: true,
      enum: ['business', 'operational', 'feedback', 'observability', 'security'],
    },
    name: {
      type: String,
      required: true,
    },
    value: {
      type: Number,
      required: true,
    },
    timestamp: {
      type: Date,
      default: Date.now,
    },
    metadata: {
      type: Map,
      of: mongoose.Schema.Types.Mixed,
      default: {},
    },
  },
  {
    timestamps: true,
  }
);

// Index for efficient querying
kpiSchema.index({ type: 1, name: 1, timestamp: -1 });

const KPI = mongoose.model<IKPI>('KPI', kpiSchema);

export default KPI; 