import { IKPI } from '../models/KPI';
import { IUser } from '../models/User';

// Mock Users
export const users: IUser[] = [
  {
    _id: '1',
    name: 'John Doe',
    email: 'john@example.com',
    password: 'hashed_password',
    role: 'admin',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: '2',
    name: 'Jane Smith',
    email: 'jane@example.com',
    password: 'hashed_password',
    role: 'user',
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

// Mock KPIs
export const kpis: IKPI[] = [
  // Business KPIs
  {
    _id: '1',
    type: 'business',
    name: 'Cost per API Call',
    value: 0.0025,
    timestamp: new Date('2024-03-15'),
    metadata: { currency: 'USD' },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: '2',
    type: 'business',
    name: 'Revenue per Use Case',
    value: 1500,
    timestamp: new Date('2024-03-15'),
    metadata: { currency: 'USD', useCase: 'ChatGPT' },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: '3',
    type: 'business',
    name: 'User Distribution',
    value: 45,
    timestamp: new Date('2024-03-15'),
    metadata: { useCase: 'ChatGPT', percentage: true },
    createdAt: new Date(),
    updatedAt: new Date(),
  },

  // Operational KPIs
  {
    _id: '4',
    type: 'operational',
    name: 'Uptime',
    value: 99.9,
    timestamp: new Date('2024-03-15'),
    metadata: { percentage: true },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: '5',
    type: 'operational',
    name: 'Error Rate',
    value: 0.1,
    timestamp: new Date('2024-03-15'),
    metadata: { percentage: true },
    createdAt: new Date(),
    updatedAt: new Date(),
  },

  // Security KPIs
  {
    _id: '6',
    type: 'security',
    name: 'Failed Login Attempts',
    value: 5,
    timestamp: new Date('2024-03-15'),
    metadata: { severity: 'low' },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: '7',
    type: 'security',
    name: 'API Key Usage',
    value: 1000,
    timestamp: new Date('2024-03-15'),
    metadata: { type: 'requests' },
    createdAt: new Date(),
    updatedAt: new Date(),
  },
];

// Mock data store
export class MockDataStore {
  private static instance: MockDataStore;
  private users: IUser[];
  private kpis: IKPI[];

  private constructor() {
    this.users = [...users];
    this.kpis = [...kpis];
  }

  public static getInstance(): MockDataStore {
    if (!MockDataStore.instance) {
      MockDataStore.instance = new MockDataStore();
    }
    return MockDataStore.instance;
  }

  // User methods
  public getUsers(): IUser[] {
    return this.users;
  }

  public getUserById(id: string): IUser | undefined {
    return this.users.find(user => user._id === id);
  }

  public getUserByEmail(email: string): IUser | undefined {
    return this.users.find(user => user.email === email);
  }

  public createUser(user: Omit<IUser, '_id' | 'createdAt' | 'updatedAt'>): IUser {
    const newUser: IUser = {
      ...user,
      _id: (this.users.length + 1).toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.users.push(newUser);
    return newUser;
  }

  public updateUser(id: string, updates: Partial<IUser>): IUser | undefined {
    const index = this.users.findIndex(user => user._id === id);
    if (index === -1) return undefined;

    this.users[index] = {
      ...this.users[index],
      ...updates,
      updatedAt: new Date(),
    };
    return this.users[index];
  }

  public deleteUser(id: string): boolean {
    const index = this.users.findIndex(user => user._id === id);
    if (index === -1) return false;

    this.users.splice(index, 1);
    return true;
  }

  // KPI methods
  public getKPIs(): IKPI[] {
    return this.kpis;
  }

  public getKPIById(id: string): IKPI | undefined {
    return this.kpis.find(kpi => kpi._id === id);
  }

  public getKPIsByType(type: string): IKPI[] {
    return this.kpis.filter(kpi => kpi.type === type);
  }

  public createKPI(kpi: Omit<IKPI, '_id' | 'createdAt' | 'updatedAt'>): IKPI {
    const newKPI: IKPI = {
      ...kpi,
      _id: (this.kpis.length + 1).toString(),
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.kpis.push(newKPI);
    return newKPI;
  }

  public updateKPI(id: string, updates: Partial<IKPI>): IKPI | undefined {
    const index = this.kpis.findIndex(kpi => kpi._id === id);
    if (index === -1) return undefined;

    this.kpis[index] = {
      ...this.kpis[index],
      ...updates,
      updatedAt: new Date(),
    };
    return this.kpis[index];
  }

  public deleteKPI(id: string): boolean {
    const index = this.kpis.findIndex(kpi => kpi._id === id);
    if (index === -1) return false;

    this.kpis.splice(index, 1);
    return true;
  }
} 